# Ultimate Gaming Hub (Phase 2 base)

1. npx create-next-app@latest ultimate-gaming-hub --ts --tailwind --app --src-dir --eslint
2. Use Tailwind v3: npm i -D tailwindcss@3 postcss autoprefixer
3. npm i @supabase/supabase-js @supabase/ssr lucide-react
4. Copy these files over the generated ones, then: cp .env.local.example .env.local && npm run dev
