import { Crown, Flame, Gem, Ghost, Rocket, Skull, Swords, Zap, type LucideIcon } from "lucide-react";

export type AvatarPreset = { id: string; label: string; from: string; to: string; icon: LucideIcon };

// Stored in profiles.avatar_url as "preset:<id>", so no image storage is needed.
export const AVATARS: AvatarPreset[] = [
  { id: "volt", label: "Volt", from: "#A855F7", to: "#22D3EE", icon: Zap },
  { id: "phantom", label: "Phantom", from: "#6D28D9", to: "#0E7490", icon: Ghost },
  { id: "rocket", label: "Rocket", from: "#22D3EE", to: "#2563EB", icon: Rocket },
  { id: "reaper", label: "Reaper", from: "#DB2777", to: "#4C1D95", icon: Skull },
  { id: "blade", label: "Blade", from: "#7C3AED", to: "#DB2777", icon: Swords },
  { id: "ember", label: "Ember", from: "#F472B6", to: "#A855F7", icon: Flame },
  { id: "crown", label: "Crown", from: "#22D3EE", to: "#A855F7", icon: Crown },
  { id: "crystal", label: "Crystal", from: "#0891B2", to: "#7C3AED", icon: Gem },
];

export const presetValue = (id: string) => `preset:${id}`;
export const resolveAvatar = (value: string | null | undefined) =>
  value?.startsWith("preset:") ? AVATARS.find((a) => a.id === value.slice(7)) ?? null : null;

// Mirrors the database: level = floor(sqrt(xp / 100)) + 1
export function levelProgress(xp: number) {
  const level = Math.floor(Math.sqrt(xp / 100)) + 1;
  const base = (level - 1) ** 2 * 100;
  const next = level ** 2 * 100;
  return { level, base, next, pct: Math.min(100, Math.round(((xp - base) / (next - base)) * 100)) };
}
