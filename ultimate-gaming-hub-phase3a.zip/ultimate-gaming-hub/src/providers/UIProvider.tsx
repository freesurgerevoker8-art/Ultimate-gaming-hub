"use client";
import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

type UIState = {
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  chatOpen: boolean;
  toggleChat: () => void;
  setChatOpen: (v: boolean) => void;
};
const Ctx = createContext<UIState | null>(null);

export function UIProvider({ children }: { children: ReactNode }) {
  const [sidebarCollapsed, setCollapsed] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const value = useMemo<UIState>(() => ({
    sidebarCollapsed, chatOpen, setChatOpen,
    toggleSidebar: () => setCollapsed((v) => !v),
    toggleChat: () => setChatOpen((v) => !v),
  }), [sidebarCollapsed, chatOpen]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useUI() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useUI must be used inside <UIProvider>");
  return c;
}
