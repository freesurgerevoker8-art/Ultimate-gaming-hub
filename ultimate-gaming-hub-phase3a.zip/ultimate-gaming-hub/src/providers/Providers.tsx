"use client";
import type { ReactNode } from "react";
import { SupabaseProvider } from "./SupabaseProvider";
import { AuthProvider } from "./AuthProvider";
import { UIProvider } from "./UIProvider";

export function Providers({ children }: { children: ReactNode }) {
  return (
    <SupabaseProvider>
      <AuthProvider>
        <UIProvider>{children}</UIProvider>
      </AuthProvider>
    </SupabaseProvider>
  );
}
