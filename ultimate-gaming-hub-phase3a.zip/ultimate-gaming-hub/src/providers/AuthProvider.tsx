"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
import { useSupabase } from "./SupabaseProvider";
import type { Profile } from "@/types/domain";

type AuthState = {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  signOut: () => Promise<void>;
};
const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const supabase = useSupabase();
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (id: string | undefined) => {
    if (!id) return setProfile(null);
    const { data } = await supabase
      .from("profiles")
      .select("id, username, bio, avatar_url, xp, level, role, is_admin")
      .eq("id", id)
      .maybeSingle();
    setProfile((data as Profile) ?? null);
  }, [supabase]);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);
      loadProfile(data.user?.id).finally(() => setLoading(false));
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user ?? null);
      loadProfile(session?.user?.id);
    });
    return () => sub.subscription.unsubscribe();
  }, [supabase, loadProfile]);

  const value = useMemo<AuthState>(() => ({
    user, profile, loading,
    refreshProfile: () => loadProfile(user?.id),
    signOut: async () => { await supabase.auth.signOut(); },
  }), [user, profile, loading, loadProfile, supabase]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used inside <AuthProvider>");
  return c;
}
