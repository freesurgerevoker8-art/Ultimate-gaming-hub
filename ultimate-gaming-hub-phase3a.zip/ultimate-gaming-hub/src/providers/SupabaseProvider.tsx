"use client";
import { createContext, useContext, useState, type ReactNode } from "react";
import type { SupabaseClient } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/client";

const Ctx = createContext<SupabaseClient | null>(null);

export function SupabaseProvider({ children }: { children: ReactNode }) {
  const [client] = useState(() => createClient()); // one client per tab
  return <Ctx.Provider value={client}>{children}</Ctx.Provider>;
}

export function useSupabase() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useSupabase must be used inside <SupabaseProvider>");
  return c;
}
