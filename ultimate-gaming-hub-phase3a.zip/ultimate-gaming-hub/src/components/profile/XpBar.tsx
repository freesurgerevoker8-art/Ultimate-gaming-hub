import { levelProgress } from "@/lib/avatars";

export function XpBar({ xp }: { xp: number }) {
  const { level, next, pct } = levelProgress(xp);
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between text-sm">
        <span className="font-display text-lg font-semibold text-neon-cyan">Level {level}</span>
        <span className="text-muted">{xp} / {next} XP</span>
      </div>
      <div
        role="progressbar"
        aria-label={`Progress to level ${level + 1}`}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={pct}
        className="h-2.5 overflow-hidden rounded-full bg-raised"
      >
        <div className="h-full rounded-full bg-neon-edge transition-[width] duration-500" style={{ width: `${Math.max(pct, 2)}%` }} />
      </div>
      <p className="mt-2 text-xs text-muted">{next - xp} XP to level {level + 1}</p>
    </div>
  );
}
