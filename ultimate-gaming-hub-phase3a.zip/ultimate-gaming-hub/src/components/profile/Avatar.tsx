import { resolveAvatar } from "@/lib/avatars";

type Props = { avatarUrl: string | null | undefined; name: string | null | undefined; size?: number };

export function Avatar({ avatarUrl, name, size = 64 }: Props) {
  const preset = resolveAvatar(avatarUrl);
  const box = { width: size, height: size };
  if (preset) {
    const Icon = preset.icon;
    return (
      <span
        role="img"
        aria-label={`${preset.label} avatar`}
        className="grid shrink-0 place-items-center rounded-2xl text-void"
        style={{ ...box, background: `linear-gradient(135deg, ${preset.from}, ${preset.to})` }}
      >
        <Icon aria-hidden size={Math.round(size * 0.5)} strokeWidth={2.2} />
      </span>
    );
  }
  return (
    <span
      role="img"
      aria-label="Default avatar"
      className="grid shrink-0 place-items-center rounded-2xl bg-raised font-display font-bold text-neon-cyan"
      style={{ ...box, fontSize: size * 0.4 }}
    >
      {(name ?? "?").slice(0, 1).toUpperCase()}
    </span>
  );
}
