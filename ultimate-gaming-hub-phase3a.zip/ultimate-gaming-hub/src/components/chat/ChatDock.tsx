"use client";
import { X } from "lucide-react";
import { useUI } from "@/providers/UIProvider";
import { cn } from "@/lib/utils";

// Shell only. Module C wires this to Supabase Realtime (chat_messages).
export function ChatDock() {
  const { chatOpen, setChatOpen } = useUI();
  return (
    <aside
      aria-label="Chat"
      aria-hidden={!chatOpen}
      className={cn(
        "z-40 flex flex-col border-line bg-panel",
        // mobile: bottom sheet; desktop: docked right column
        "fixed inset-x-0 bottom-0 h-[70dvh] rounded-t-2xl border-t transition-transform md:sticky md:top-0 md:h-dvh md:w-80 md:shrink-0 md:rounded-none md:border-l md:border-t-0 md:transition-none",
        chatOpen ? "translate-y-0" : "translate-y-full md:hidden"
      )}
    >
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <h2 className="font-display text-base font-semibold">Global chat</h2>
        <button onClick={() => setChatOpen(false)} aria-label="Close chat" className="rounded-md p-1 text-muted hover:bg-raised hover:text-ink">
          <X aria-hidden className="size-5" />
        </button>
      </div>
      <p className="m-auto px-6 text-center text-sm text-muted">Messages will appear here once chat is connected.</p>
    </aside>
  );
}
