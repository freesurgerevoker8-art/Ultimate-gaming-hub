"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LogIn, LogOut, PanelLeftClose, PanelLeftOpen, UserRound } from "lucide-react";
import { NAV_ITEMS } from "./nav-items";
import { useAuth } from "@/providers/AuthProvider";
import { useUI } from "@/providers/UIProvider";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const path = usePathname();
  const { profile, user, signOut } = useAuth();
  const { sidebarCollapsed, toggleSidebar } = useUI();
  const profileHref = user ? "/profile" : "/login";
  const active = (href: string) => (href === "/" ? path === "/" : path.startsWith(href));

  const item = (href: string, label: string, Icon: typeof UserRound) => (
    <Link
      key={href}
      href={href}
      aria-current={active(href) ? "page" : undefined}
      title={sidebarCollapsed ? label : undefined}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted transition-colors hover:bg-raised hover:text-ink",
        active(href) && "neon-edge bg-raised text-ink"
      )}
    >
      <Icon aria-hidden className="size-5 shrink-0" />
      <span className={cn(sidebarCollapsed && "sr-only")}>{label}</span>
    </Link>
  );

  return (
    <aside
      aria-label="Main navigation"
      className={cn(
        "sticky top-0 hidden h-dvh shrink-0 flex-col border-r border-line bg-panel py-4 transition-[width] md:flex",
        sidebarCollapsed ? "w-[72px] px-2" : "w-60 px-3"
      )}
    >
      <Link href="/" className="mb-6 flex items-center gap-2 px-2 font-display text-lg font-bold">
        <span aria-hidden className="grid size-8 place-items-center rounded-lg bg-neon-edge text-void">U</span>
        <span className={cn(sidebarCollapsed && "sr-only")}>Ultimate Hub</span>
      </Link>

      <nav className="flex flex-1 flex-col gap-1">
        {NAV_ITEMS.map((n) => item(n.href, n.label, n.icon))}
        {item(profileHref, user ? "My profile" : "Sign in", user ? UserRound : LogIn)}
      </nav>

      <div className="mt-4 space-y-1 border-t border-line pt-3">
        {user && (
          <button onClick={signOut} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted hover:bg-raised hover:text-ink">
            <LogOut aria-hidden className="size-5 shrink-0" />
            <span className={cn(sidebarCollapsed && "sr-only")}>Sign out</span>
          </button>
        )}
        <button
          onClick={toggleSidebar}
          aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-expanded={!sidebarCollapsed}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted hover:bg-raised hover:text-ink"
        >
          {sidebarCollapsed ? <PanelLeftOpen aria-hidden className="size-5" /> : <PanelLeftClose aria-hidden className="size-5" />}
          <span className={cn(sidebarCollapsed && "sr-only")}>Collapse</span>
        </button>
      </div>
    </aside>
  );
}
