"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { MessageSquare, Search } from "lucide-react";
import { useAuth } from "@/providers/AuthProvider";
import { useUI } from "@/providers/UIProvider";

export function TopBar() {
  const router = useRouter();
  const { profile } = useAuth();
  const { chatOpen, toggleChat } = useUI();
  const [q, setQ] = useState("");

  return (
    <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-void/85 px-4 py-3 backdrop-blur" style={{ paddingTop: "max(0.75rem, env(safe-area-inset-top))" }}>
      <form
        role="search"
        className="relative max-w-xl flex-1"
        onSubmit={(e) => { e.preventDefault(); router.push(q ? `/?q=${encodeURIComponent(q)}` : "/"); }}
      >
        <label htmlFor="global-search" className="sr-only">Search games</label>
        <Search aria-hidden className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
        <input
          id="global-search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search 1,000+ games"
          className="w-full rounded-lg border border-line bg-panel py-2 pl-9 pr-3 text-sm placeholder:text-muted focus:border-neon-cyan"
        />
      </form>

      <div className="ml-auto flex items-center gap-2">
        {profile && (
          <span className="hidden items-center gap-2 rounded-full border border-line bg-panel px-3 py-1 text-sm sm:flex" aria-label={`Level ${profile.level}, ${profile.xp} XP`}>
            <span className="font-display font-semibold text-neon-cyan">Lv {profile.level}</span>
            <span className="text-muted">{profile.xp} XP</span>
          </span>
        )}
        <button
          onClick={toggleChat}
          aria-pressed={chatOpen}
          aria-label="Toggle chat"
          className="hidden items-center gap-2 rounded-lg border border-line bg-panel px-3 py-2 text-sm hover:shadow-glow-cyan md:flex"
        >
          <MessageSquare aria-hidden className="size-4 text-neon-cyan" />
          Chat
        </button>
      </div>
    </header>
  );
}
