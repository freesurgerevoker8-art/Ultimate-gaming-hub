"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { MessageSquare, UserRound } from "lucide-react";
import { NAV_ITEMS } from "./nav-items";
import { useAuth } from "@/providers/AuthProvider";
import { useUI } from "@/providers/UIProvider";
import { cn } from "@/lib/utils";

export function MobileNav() {
  const path = usePathname();
  const { profile, user } = useAuth();
  const { chatOpen, toggleChat } = useUI();
  const profileHref = user ? "/profile" : "/login";
  const tab = "flex flex-1 flex-col items-center gap-1 py-2 text-xs text-muted";
  const on = "text-neon-cyan";

  return (
    <nav aria-label="Mobile navigation" className="safe-bottom fixed inset-x-0 bottom-0 z-30 flex border-t border-line bg-panel/95 backdrop-blur md:hidden">
      {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
        const isOn = href === "/" ? path === "/" : path.startsWith(href);
        return (
          <Link key={href} href={href} aria-current={isOn ? "page" : undefined} className={cn(tab, isOn && on)}>
            <Icon aria-hidden className="size-5" />{label}
          </Link>
        );
      })}
      <button onClick={toggleChat} aria-pressed={chatOpen} className={cn(tab, chatOpen && on)}>
        <MessageSquare aria-hidden className="size-5" />Chat
      </button>
      <Link href={profileHref} className={cn(tab, path.startsWith("/profile") && on)}>
        <UserRound aria-hidden className="size-5" />{profile ? "Profile" : "Sign in"}
      </Link>
    </nav>
  );
}
