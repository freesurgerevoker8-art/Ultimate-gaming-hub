import { Gamepad2, Trophy } from "lucide-react";

export const NAV_ITEMS = [
  { href: "/", label: "Games", icon: Gamepad2 },
  { href: "/tournaments", label: "Tournaments", icon: Trophy },
] as const;
