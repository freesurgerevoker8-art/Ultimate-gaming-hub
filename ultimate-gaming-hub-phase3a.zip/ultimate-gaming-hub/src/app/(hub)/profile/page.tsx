"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2 } from "lucide-react";
import { useSupabase } from "@/providers/SupabaseProvider";
import { useAuth } from "@/providers/AuthProvider";
import { Avatar } from "@/components/profile/Avatar";
import { XpBar } from "@/components/profile/XpBar";
import { AVATARS, presetValue } from "@/lib/avatars";
import { cn } from "@/lib/utils";

const BIO_MAX = 280;
type Status = "idle" | "saving" | "saved" | "error";

export default function ProfilePage() {
  const router = useRouter();
  const supabase = useSupabase();
  const { user, profile, loading, refreshProfile } = useAuth();

  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!loading && !user) router.replace("/login?next=/profile");
  }, [loading, user, router]);

  useEffect(() => {
    if (profile) { setBio(profile.bio ?? ""); setAvatar(profile.avatar_url); }
  }, [profile?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading || !user || !profile) {
    return (
      <div aria-busy="true" aria-label="Loading profile" className="mx-auto max-w-2xl space-y-4">
        <div className="h-32 animate-pulse rounded-2xl bg-panel" />
        <div className="h-48 animate-pulse rounded-2xl bg-panel" />
      </div>
    );
  }

  const dirty = bio !== (profile.bio ?? "") || avatar !== profile.avatar_url;

  async function save() {
    if (!user) return;
    setStatus("saving"); setMessage("");
    const { error } = await supabase
      .from("profiles")
      .update({ bio: bio.trim() || null, avatar_url: avatar, updated_at: new Date().toISOString() })
      .eq("id", user.id);
    if (error) { setStatus("error"); setMessage("Couldn't save your changes. Try again."); return; }
    await refreshProfile();
    setStatus("saved"); setMessage("Profile saved.");
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <section aria-labelledby="me-h" className="rounded-2xl border border-line bg-panel p-5 sm:p-6">
        <div className="flex items-center gap-4">
          <Avatar avatarUrl={avatar} name={profile.username} size={80} />
          <div className="min-w-0">
            <h1 id="me-h" className="truncate text-2xl font-bold">{profile.username ?? "Player"}</h1>
            <p className="truncate text-sm text-muted">{user.email}</p>
            {profile.role !== "user" && (
              <span className="mt-1 inline-block rounded-full border border-neon-purple/50 px-2 py-0.5 text-xs text-neon-purple">{profile.role === "admin" ? "Admin" : "Moderator"}</span>
            )}
          </div>
        </div>
        <div className="mt-6"><XpBar xp={profile.xp} /></div>
      </section>

      <section aria-labelledby="avatar-h" className="rounded-2xl border border-line bg-panel p-5 sm:p-6">
        <h2 id="avatar-h" className="text-lg font-semibold">Choose your avatar</h2>
        <div role="radiogroup" aria-labelledby="avatar-h" className="mt-4 grid grid-cols-4 gap-3">
          {AVATARS.map((a) => {
            const value = presetValue(a.id);
            const on = avatar === value;
            return (
              <button
                key={a.id}
                type="button"
                role="radio"
                aria-checked={on}
                aria-label={a.label}
                onClick={() => setAvatar(value)}
                className={cn("relative grid place-items-center rounded-2xl p-2 transition-shadow", on ? "bg-raised shadow-glow-cyan" : "hover:bg-raised")}
              >
                <Avatar avatarUrl={value} name={a.label} size={56} />
                <span className="mt-1.5 text-xs text-muted">{a.label}</span>
                {on && <Check aria-hidden className="absolute right-1.5 top-1.5 size-4 rounded-full bg-neon-cyan p-0.5 text-void" />}
              </button>
            );
          })}
        </div>
      </section>

      <section aria-labelledby="bio-h" className="rounded-2xl border border-line bg-panel p-5 sm:p-6">
        <h2 id="bio-h" className="text-lg font-semibold">Bio</h2>
        <label htmlFor="bio" className="sr-only">Short bio</label>
        <textarea
          id="bio"
          value={bio}
          onChange={(e) => setBio(e.target.value.slice(0, BIO_MAX))}
          rows={4}
          placeholder="Favorite genres, your best score, who you play with..."
          className="mt-3 w-full resize-none rounded-lg border border-line bg-raised p-3 text-base placeholder:text-muted focus:border-neon-cyan"
        />
        <p className="mt-1 text-right text-xs text-muted" aria-live="polite">{bio.length}/{BIO_MAX}</p>
      </section>

      <div className="flex items-center gap-4">
        <button
          onClick={save}
          disabled={!dirty || status === "saving"}
          className="flex items-center gap-2 rounded-lg bg-neon-edge px-6 py-3 font-display font-semibold text-void transition-opacity hover:shadow-glow-purple disabled:opacity-50"
        >
          {status === "saving" && <Loader2 aria-hidden className="size-5 animate-spin" />}
          {status === "saving" ? "Saving" : "Save changes"}
        </button>
        <p role="status" aria-live="polite" className={cn("text-sm", status === "error" ? "text-danger" : "text-neon-cyan")}>{message}</p>
      </div>
    </div>
  );
}
