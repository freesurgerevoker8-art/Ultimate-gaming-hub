import { MOCK_GAMES } from "@/data/mock-games";

// Placeholder: Module B replaces this with the virtualized catalog.
export default function Home() {
  return (
    <section aria-labelledby="games-h">
      <h1 id="games-h" className="mb-4 text-2xl font-bold">Games</h1>
      <ul className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {MOCK_GAMES.map((g) => (
          <li key={g.id} className="card-neon overflow-hidden">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={g.thumbnail_url} alt="" className="aspect-video w-full object-cover" />
            <div className="p-3 text-sm font-medium">{g.title}</div>
          </li>
        ))}
      </ul>
    </section>
  );
}
