import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { MobileNav } from "@/components/layout/MobileNav";
import { ChatDock } from "@/components/chat/ChatDock";

export default function HubLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-dvh">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar />
        <main id="main" className="flex-1 px-4 pb-24 pt-6 md:pb-8">{children}</main>
      </div>
      <ChatDock />
      <MobileNav />
    </div>
  );
}
