import type { Metadata, Viewport } from "next";
import { Chakra_Petch, DM_Sans } from "next/font/google";
import "./globals.css";
import { Providers } from "@/providers/Providers";

const display = Chakra_Petch({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-display" });
const body = DM_Sans({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = {
  title: { default: "Ultimate Gaming Hub", template: "%s | Ultimate Gaming Hub" },
  description: "Play 1,000+ browser games, chat live and compete in tournaments.",
};
export const viewport: Viewport = { themeColor: "#0A0A12", viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`dark ${display.variable} ${body.variable}`}>
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-md focus:bg-neon-purple focus:px-3 focus:py-2 focus:text-void">
          Skip to content
        </a>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
