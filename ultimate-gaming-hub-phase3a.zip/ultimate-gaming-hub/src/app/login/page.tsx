"use client";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Gamepad2, Loader2, Lock, Mail, MailCheck, UserRound } from "lucide-react";
import { useSupabase } from "@/providers/SupabaseProvider";
import { useAuth } from "@/providers/AuthProvider";
import { cn } from "@/lib/utils";

type Mode = "signin" | "signup";
const USERNAME_RE = /^[A-Za-z0-9_]{3,20}$/;

function friendly(message: string) {
  const m = message.toLowerCase();
  if (m.includes("invalid login")) return "That email and password don't match. Try again.";
  if (m.includes("not confirmed")) return "Confirm your email first. We sent you a link when you signed up.";
  if (m.includes("rate limit") || m.includes("too many")) return "Too many attempts. Wait a minute, then try again.";
  if (m.includes("password")) return "Use a password with at least 8 characters.";
  return message;
}

function Field({ id, label, icon, children }: { id: string; label: string; icon: ReactNode; children: ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-ink">{label}</label>
      <div className="relative">
        <span aria-hidden className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted">{icon}</span>
        {children}
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-line bg-raised py-3 pl-10 pr-3 text-base text-ink placeholder:text-muted focus:border-neon-cyan disabled:opacity-60";

export default function LoginPage() {
  const router = useRouter();
  const supabase = useSupabase();
  const { user, loading } = useAuth();

  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sentTo, setSentTo] = useState<string | null>(null);

  const nextPath = () => {
    const n = new URLSearchParams(window.location.search).get("next") ?? "/";
    return n.startsWith("/") && !n.startsWith("//") ? n : "/";
  };

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("error") === "auth")
      setError("That confirmation link is invalid or expired. Log in or sign up again.");
  }, []);

  useEffect(() => {
    if (!loading && user) router.replace(nextPath());
  }, [loading, user, router]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError(null);

    if (mode === "signup") {
      if (!USERNAME_RE.test(username)) return setError("Usernames use 3 to 20 letters, numbers or underscores.");
      if (password.length < 8) return setError("Use a password with at least 8 characters.");
    }

    setBusy(true);
    if (mode === "signin") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) { setError(friendly(error.message)); setBusy(false); return; }
      router.replace(nextPath());
      router.refresh(); // spinner stays on until the page changes
      return;
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { username }, emailRedirectTo: `${window.location.origin}/auth/callback` },
    });
    if (error) { setError(friendly(error.message)); setBusy(false); return; }
    if (data.user && data.user.identities?.length === 0) {
      setError("An account with this email already exists. Log in instead.");
      setBusy(false);
      return;
    }
    if (data.session) { router.replace(nextPath()); router.refresh(); return; }
    setSentTo(email);
    setBusy(false);
  }

  const switchMode = (m: Mode) => { setMode(m); setError(null); };

  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      {/* Brand side: desktop only */}
      <aside className="relative hidden overflow-hidden border-r border-line bg-panel lg:block">
        <div aria-hidden className="absolute -left-24 -top-24 size-96 rounded-full bg-neon-purple/25 blur-3xl" />
        <div aria-hidden className="absolute -bottom-32 right-0 size-96 rounded-full bg-neon-cyan/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <div className="flex items-center gap-2 font-display text-xl font-bold">
            <span aria-hidden className="grid size-9 place-items-center rounded-lg bg-neon-edge text-void"><Gamepad2 className="size-5" /></span>
            Ultimate Hub
          </div>
          <div>
            <h2 className="max-w-md font-display text-4xl font-bold leading-tight">Your next match is one login away.</h2>
            <p className="mt-4 max-w-sm text-muted">Save your favorite games, level up your profile, and enter live tournaments.</p>
          </div>
        </div>
      </aside>

      <main id="main" className="flex items-center justify-center px-5 py-10" style={{ paddingTop: "max(2.5rem, env(safe-area-inset-top))", paddingBottom: "max(2.5rem, env(safe-area-inset-bottom))" }}>
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-2 font-display text-lg font-bold lg:hidden">
            <span aria-hidden className="grid size-8 place-items-center rounded-lg bg-neon-edge text-void"><Gamepad2 className="size-4" /></span>
            Ultimate Hub
          </div>

          {sentTo ? (
            <div role="status" className="rounded-2xl border border-line bg-panel p-6 text-center">
              <MailCheck aria-hidden className="mx-auto mb-3 size-10 text-neon-cyan" />
              <h1 className="text-xl font-semibold">Check your email</h1>
              <p className="mt-2 text-sm text-muted">We sent a confirmation link to <span className="text-ink">{sentTo}</span>. Open it on this device to finish signing up.</p>
              <button onClick={() => { setSentTo(null); switchMode("signin"); }} className="mt-5 text-sm font-medium text-neon-cyan hover:underline">Back to log in</button>
            </div>
          ) : (
            <>
              <h1 className="text-3xl font-bold">{mode === "signin" ? "Welcome back" : "Create your account"}</h1>
              <p className="mt-1 text-sm text-muted">{mode === "signin" ? "Log in to pick up your games and rank." : "It takes under a minute."}</p>

              <div role="tablist" aria-label="Log in or sign up" className="mt-6 grid grid-cols-2 rounded-lg border border-line bg-panel p-1">
                {(["signin", "signup"] as Mode[]).map((m) => (
                  <button
                    key={m}
                    role="tab"
                    type="button"
                    aria-selected={mode === m}
                    onClick={() => switchMode(m)}
                    className={cn("rounded-md py-2 text-sm font-medium transition-colors", mode === m ? "bg-raised text-ink shadow-glow-purple" : "text-muted hover:text-ink")}
                  >
                    {m === "signin" ? "Log in" : "Sign up"}
                  </button>
                ))}
              </div>

              <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4" aria-busy={busy}>
                {mode === "signup" && (
                  <Field id="username" label="Username" icon={<UserRound className="size-4" />}>
                    <input id="username" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="pixel_pilot" maxLength={20} disabled={busy} className={inputCls} />
                  </Field>
                )}
                <Field id="email" label="Email" icon={<Mail className="size-4" />}>
                  <input id="email" type="email" inputMode="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" disabled={busy} className={inputCls} />
                </Field>
                <Field id="password" label="Password" icon={<Lock className="size-4" />}>
                  <input id="password" type={showPw ? "text" : "password"} autoComplete={mode === "signin" ? "current-password" : "new-password"} required value={password} onChange={(e) => setPassword(e.target.value)} placeholder={mode === "signup" ? "At least 8 characters" : "Your password"} disabled={busy} className={cn(inputCls, "pr-11")} />
                  <button type="button" onClick={() => setShowPw((v) => !v)} aria-label={showPw ? "Hide password" : "Show password"} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-muted hover:text-ink">
                    {showPw ? <EyeOff aria-hidden className="size-4" /> : <Eye aria-hidden className="size-4" />}
                  </button>
                </Field>

                <p role="alert" className={cn("rounded-lg border border-danger/40 bg-danger/10 px-3 py-2 text-sm text-danger", !error && "hidden")}>{error}</p>

                <button
                  type="submit"
                  disabled={busy || !email || !password}
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-neon-edge py-3 font-display text-base font-semibold text-void transition-opacity hover:shadow-glow-purple disabled:opacity-60"
                >
                  {busy && <Loader2 aria-hidden className="size-5 animate-spin" />}
                  {busy ? (mode === "signin" ? "Logging in" : "Creating account") : mode === "signin" ? "Log in" : "Create account"}
                </button>
              </form>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
