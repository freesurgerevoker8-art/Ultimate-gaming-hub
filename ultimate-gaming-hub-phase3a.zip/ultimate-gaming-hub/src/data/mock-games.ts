import type { Game } from "@/types/domain";

// Inline SVG thumbnails: no remote images needed while testing.
const thumb = (a: string, b: string, label: string) =>
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="320" height="180" fill="url(#g)"/><text x="160" y="100" font-family="sans-serif" font-size="26" font-weight="700" fill="#fff" text-anchor="middle">${label}</text></svg>`
  );

// TODO: replace embed_url values with real HTML5 game URLs. These point to example.com so the iframe pipeline can be tested.
export const MOCK_GAMES: Game[] = [
  { id: "m1", slug: "neon-racer", title: "Neon Racer", description: "Drift through a synthwave city.", thumbnail_url: thumb("#7C3AED", "#22D3EE", "Neon Racer"), embed_url: "https://example.com/", tags: ["racing", "arcade"], orientation: "landscape", is_active: true, play_count: 1240 },
  { id: "m2", slug: "block-smash", title: "Block Smash", description: "Classic brick breaker with power-ups.", thumbnail_url: thumb("#DB2777", "#7C3AED", "Block Smash"), embed_url: "https://example.com/", tags: ["arcade", "puzzle"], orientation: "portrait", is_active: true, play_count: 860 },
  { id: "m3", slug: "star-defender", title: "Star Defender", description: "Hold the line against alien waves.", thumbnail_url: thumb("#0E7490", "#4C1D95", "Star Defender"), embed_url: "https://example.com/", tags: ["shooter", "space"], orientation: "landscape", is_active: true, play_count: 2310 },
  { id: "m4", slug: "word-forge", title: "Word Forge", description: "Build words, beat the clock.", thumbnail_url: thumb("#6D28D9", "#0891B2", "Word Forge"), embed_url: "https://example.com/", tags: ["puzzle", "word"], orientation: "landscape", is_active: true, play_count: 430 },
];
