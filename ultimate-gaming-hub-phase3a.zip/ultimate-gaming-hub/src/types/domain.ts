export type Game = {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  thumbnail_url: string;
  embed_url: string;
  embed_origin?: string;
  tags: string[];
  orientation: "landscape" | "portrait";
  is_active: boolean;
  play_count: number;
};

export type Profile = {
  id: string;
  username: string | null;
  bio: string | null;
  avatar_url: string | null;
  xp: number;
  level: number;
  role: "user" | "moderator" | "admin";
  is_admin: boolean;
};
