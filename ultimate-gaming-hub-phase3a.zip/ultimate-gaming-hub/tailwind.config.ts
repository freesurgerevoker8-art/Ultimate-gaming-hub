import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        void: "#0A0A12",     // page background
        panel: "#12121F",    // sidebar, chat, cards
        raised: "#1B1B30",   // hover / inputs
        line: "#2A2A45",     // borders
        ink: "#E8E8F5",      // primary text
        muted: "#9393B2",    // secondary text (AA on void)
        neon: { purple: "#A855F7", cyan: "#22D3EE" },
        danger: "#FB7185",
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        "glow-purple": "0 0 0 1px rgba(168,85,247,.55), 0 0 22px -4px rgba(168,85,247,.6)",
        "glow-cyan": "0 0 0 1px rgba(34,211,238,.55), 0 0 22px -4px rgba(34,211,238,.55)",
      },
      backgroundImage: {
        "neon-edge": "linear-gradient(135deg, #A855F7, #22D3EE)",
      },
      keyframes: {
        sweep: {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(250%)" },
        },
      },
      animation: { sweep: "sweep 1.4s ease-in-out infinite" },
    },
  },
  plugins: [],
};
export default config;
